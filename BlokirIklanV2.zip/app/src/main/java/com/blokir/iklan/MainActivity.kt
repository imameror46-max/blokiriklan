package com.blokir.iklan

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var btn: Button
    private lateinit var adapter: ArrayAdapter<String>
    private var items: List<LogItem> = emptyList()
    private var seen = -1

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Store.init(this)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(40), dp(16), dp(8))

        val info = TextView(this)
        info.text = "Matikan DNS Pribadi di Pengaturan dulu. Nyalakan pemblokir, lalu buka Melolo. " +
            "Domain yang diminta HP muncul di bawah. Tap domain judi untuk memblokirnya."
        root.addView(info)

        btn = Button(this)
        btn.setOnClickListener { toggle() }
        root.addView(btn)

        val row = LinearLayout(this)
        val input = EditText(this)
        input.hint = "domain atau kata kunci"
        input.setSingleLine()
        val add = Button(this)
        add.text = "Blokir"
        add.setOnClickListener {
            val t = input.text.toString().trim().lowercase()
            if (t.isNotEmpty()) {
                if (t.contains('.')) Store.addDomain(t) else Store.addKeyword(t)
                input.setText("")
                Toast.makeText(this, "Ditambahkan: $t", Toast.LENGTH_SHORT).show()
            }
        }
        row.addView(input, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(add)
        root.addView(row)

        val list = ListView(this)
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, ArrayList<String>())
        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ ->
            if (pos < items.size) askItem(items[pos])
        }
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun askItem(it: LogItem) {
        val inList = Store.hasDomain(it.host)
        val msg = if (it.blocked) {
            if (inList) "Hapus ${it.host} dari daftar blokir?" else "${it.host} diblokir oleh kata kunci."
        } else "Blokir ${it.host}?"
        val d = AlertDialog.Builder(this).setMessage(msg).setNegativeButton("Batal", null)
        if (!it.blocked) d.setPositiveButton("Blokir") { _, _ -> Store.addDomain(it.host) }
        else if (inList) d.setPositiveButton("Hapus") { _, _ -> Store.removeDomain(it.host) }
        d.show()
    }

    private fun toggle() {
        if (Store.running) {
            val i = Intent(this, BlockVpnService::class.java)
            i.action = "STOP"
            startService(i)
        } else {
            val p = VpnService.prepare(this)
            if (p != null) startActivityForResult(p, 1) else startVpn()
        }
    }

    private fun startVpn() { startService(Intent(this, BlockVpnService::class.java)) }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        if (req == 1 && res == RESULT_OK) startVpn()
    }

    private val tick = object : Runnable {
        override fun run() { refresh(); h.postDelayed(this, 800) }
    }

    override fun onResume() { super.onResume(); tick.run() }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }

    private fun refresh() {
        btn.text = if (Store.running) "Matikan pemblokir" else "Nyalakan pemblokir"
        if (seen != Store.version) {
            seen = Store.version
            items = Store.snapshot()
            adapter.clear()
            adapter.addAll(items.map { (if (it.blocked) "⛔ " else "✅ ") + it.host })
        }
    }
}
