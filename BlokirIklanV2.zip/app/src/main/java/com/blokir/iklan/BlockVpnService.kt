package com.blokir.iklan

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.Executors

class BlockVpnService : VpnService() {
    private var tun: ParcelFileDescriptor? = null
    @Volatile private var active = false
    private val pool = Executors.newFixedThreadPool(8)

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Store.init(this)
        if (intent?.action == "STOP") { shutdown(); return START_NOT_STICKY }
        startVpn()
        return START_STICKY
    }

    private fun startVpn() {
        if (active) return
        val fd = Builder()
            .setSession("Blokir Iklan")
            .addAddress("10.111.0.1", 32)
            .addDnsServer("10.111.0.2")
            .addRoute("10.111.0.2", 32)
            .setBlocking(true)
            .establish() ?: return
        tun = fd
        active = true
        Store.running = true
        Thread { loop(fd) }.start()
    }

    private fun loop(fd: ParcelFileDescriptor) {
        val inp = FileInputStream(fd.fileDescriptor)
        val out = FileOutputStream(fd.fileDescriptor)
        val buf = ByteArray(32767)
        try {
            while (active) {
                val n = inp.read(buf)
                if (n < 0) break
                if (n < 28) continue
                if ((buf[0].toInt() shr 4) != 4) continue
                val ihl = (buf[0].toInt() and 0x0F) * 4
                if (buf[9].toInt() != 17 || n < ihl + 8 + 12) continue
                val dport = ((buf[ihl + 2].toInt() and 0xFF) shl 8) or (buf[ihl + 3].toInt() and 0xFF)
                if (dport != 53) continue
                val pkt = buf.copyOf(n)
                pool.execute { handle(pkt, ihl, out) }
            }
        } catch (_: Exception) {
        }
    }

    private fun handle(pkt: ByteArray, ihl: Int, out: FileOutputStream) {
        val dns = pkt.copyOfRange(ihl + 8, pkt.size)
        val host = qname(dns) ?: return
        if (Store.isBlocked(host)) {
            Store.addLog(host, true)
            dns[2] = 0x81.toByte()
            dns[3] = 0x83.toByte()
            reply(pkt, ihl, dns, out)
        } else {
            Store.addLog(host, false)
            forward(pkt, ihl, dns, out)
        }
    }

    private fun forward(pkt: ByteArray, ihl: Int, dns: ByteArray, out: FileOutputStream) {
        try {
            DatagramSocket().use { s ->
                protect(s)
                s.soTimeout = 4000
                s.connect(InetAddress.getByName("1.1.1.1"), 53)
                s.send(DatagramPacket(dns, dns.size))
                val rb = ByteArray(4096)
                val rp = DatagramPacket(rb, rb.size)
                s.receive(rp)
                reply(pkt, ihl, rb.copyOf(rp.length), out)
            }
        } catch (_: Exception) {
        }
    }

    private fun qname(d: ByteArray): String? {
        var i = 12
        val sb = StringBuilder()
        while (i < d.size) {
            val l = d[i].toInt() and 0xFF
            if (l == 0) break
            if (l > 63 || i + 1 + l > d.size) return null
            if (sb.isNotEmpty()) sb.append('.')
            sb.append(String(d, i + 1, l, Charsets.US_ASCII))
            i += l + 1
        }
        return if (sb.isEmpty()) null else sb.toString().lowercase()
    }

    private fun reply(req: ByteArray, ihl: Int, dns: ByteArray, out: FileOutputStream) {
        val total = ihl + 8 + dns.size
        val o = ByteArray(total)
        System.arraycopy(req, 0, o, 0, ihl + 8)
        System.arraycopy(req, 16, o, 12, 4)
        System.arraycopy(req, 12, o, 16, 4)
        o[ihl] = req[ihl + 2]; o[ihl + 1] = req[ihl + 3]
        o[ihl + 2] = req[ihl]; o[ihl + 3] = req[ihl + 1]
        o[2] = (total shr 8).toByte(); o[3] = total.toByte()
        o[8] = 64
        o[10] = 0; o[11] = 0
        val udpLen = 8 + dns.size
        o[ihl + 4] = (udpLen shr 8).toByte(); o[ihl + 5] = udpLen.toByte()
        o[ihl + 6] = 0; o[ihl + 7] = 0
        System.arraycopy(dns, 0, o, ihl + 8, dns.size)
        var sum = 0
        var i = 0
        while (i < ihl) {
            sum += ((o[i].toInt() and 0xFF) shl 8) or (o[i + 1].toInt() and 0xFF)
            i += 2
        }
        while ((sum shr 16) != 0) sum = (sum and 0xFFFF) + (sum shr 16)
        val cs = sum.inv() and 0xFFFF
        o[10] = (cs shr 8).toByte(); o[11] = cs.toByte()
        synchronized(out) { out.write(o) }
    }

    private fun shutdown() {
        active = false
        Store.running = false
        try { tun?.close() } catch (_: Exception) {}
        tun = null
        stopSelf()
    }

    override fun onRevoke() { shutdown() }
    override fun onDestroy() { shutdown(); super.onDestroy() }
}
