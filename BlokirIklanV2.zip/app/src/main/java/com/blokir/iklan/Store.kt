package com.blokir.iklan

import android.content.Context
import android.content.SharedPreferences

class LogItem(val host: String, val blocked: Boolean)

object Store {
    private var p: SharedPreferences? = null
    @Volatile var running = false
    @Volatile var version = 0
    private val log = ArrayList<LogItem>()

    private val defDomains = setOf("zi389vvu4j.com", "yy739vy33.com")
    private val defKeywords = setOf("slot", "gacor", "togel", "judi", "maxwin", "st88")

    fun init(c: Context) {
        if (p == null) p = c.applicationContext.getSharedPreferences("blokir", Context.MODE_PRIVATE)
    }

    private fun get(k: String, d: Set<String>): Set<String> = HashSet(p!!.getStringSet(k, d) ?: d)
    private fun put(k: String, s: Set<String>) { p!!.edit().putStringSet(k, s).apply(); version++ }

    fun addDomain(d: String) { put("d", get("d", defDomains) + d) }
    fun removeDomain(d: String) { put("d", get("d", defDomains) - d) }
    fun addKeyword(k: String) { put("k", get("k", defKeywords) + k) }
    fun hasDomain(d: String): Boolean = get("d", defDomains).contains(d)

    fun isBlocked(h: String): Boolean {
        for (d in get("d", defDomains)) if (h == d || h.endsWith(".$d")) return true
        for (k in get("k", defKeywords)) if (h.contains(k)) return true
        return false
    }

    fun addLog(h: String, b: Boolean) {
        synchronized(log) {
            val it = log.iterator()
            while (it.hasNext()) { if (it.next().host == h) it.remove() }
            log.add(0, LogItem(h, b))
            while (log.size > 300) log.removeAt(log.size - 1)
            version++
        }
    }

    fun snapshot(): List<LogItem> = synchronized(log) { ArrayList(log) }
}
